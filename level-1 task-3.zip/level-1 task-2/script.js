document.addEventListener('DOMContentLoaded', () => {
    const display = document.getElementById('display');
    const buttons = document.querySelectorAll('.button');
    let currentInput = '0';
    let operator = null;
    let previousInput = '';
    let resetDisplay = false;
    function updateDisplay() {
        display.textContent = currentInput;
    }
    function handleNumber(buttonValue) {
        if (resetDisplay) {
            currentInput = buttonValue;
            resetDisplay = false;
        } else if (currentInput === '0' && buttonValue !== '.') {
            currentInput = buttonValue;
        } else if (buttonValue === '.' && currentInput.includes('.')) {
            return;
        } else {
            currentInput += buttonValue;
        }
        updateDisplay();
    }
    function handleOperator(buttonValue) {
        if (operator && !resetDisplay) {
            previousInput = calculate();
            currentInput = previousInput; // Update currentInput with the result
        } else {
            previousInput = currentInput;
        }
        operator = buttonValue;
        resetDisplay = true;
        updateDisplay(); // Show the current input (which is previousInput now)
    }
    function calculate() {
        let result;
        const prev = parseFloat(previousInput);
        const current = parseFloat(currentInput);
        if (isNaN(prev) || isNaN(current)) return;
        switch (operator) {
            case '+':
                result = prev + current;
                break;
            case '-':
                result = prev - current;
                break;
            case '*':
                result = prev * current;
                break;
            case '/':
                if (current === 0) {
                    alert("Cannot divide by zero!");
                    return 'Error'; // Handle division by zero
                }
                result = prev / current;
                break;
            default:
                return currentInput; // If no operator, just return current input
        }
        return parseFloat(result.toFixed(5)).toString(); // Example: round to 5 decimal places
    }
    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const buttonValue = button.textContent;

            if (button.classList.contains('number') || button.classList.contains('decimal')) {
                handleNumber(buttonValue);
            } else if (button.classList.contains('operator')) {
                handleOperator(buttonValue);
            } else if (button.classList.contains('equals')) {
                if (operator && previousInput !== '') {
                    currentInput = calculate();
                    operator = null; // Reset operator after calculation
                    previousInput = ''; // Reset previous input
                    resetDisplay = true; // Ready for a new calculation
                    updateDisplay();
                }
            } else if (button.classList.contains('clear')) {
                currentInput = '0';
                operator = null;
                previousInput = '';
                resetDisplay = false;
                updateDisplay();
            }
        });
    });
    // Initial display
    updateDisplay();
});